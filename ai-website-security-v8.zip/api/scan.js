import { db } from 'hatchable';
export const access = 'user';
export const methods = ['POST'];

function validateTarget(raw) {
  if (typeof raw !== 'string' || raw.length > 2048) throw new Error('Enter a valid website URL.');
  let u;
  try { u = new URL(raw.trim()); } catch { throw new Error('Enter a complete URL such as https://example.com'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Only HTTP and HTTPS URLs are supported.');
  if (u.username || u.password) throw new Error('URLs containing credentials are not allowed.');
  if (u.port && !['80','443'].includes(u.port)) throw new Error('Only standard web ports 80 and 443 are allowed.');
  const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (!h.includes('.') || h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal') || h.endsWith('.test') || h.endsWith('.invalid')) throw new Error('Private, local, and non-public hostnames are not allowed.');
  if (/^(127\.|10\.|192\.168\.|169\.254\.|0\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h) || h === '::1' || h.startsWith('fc') || h.startsWith('fd') || h.startsWith('fe80')) throw new Error('Private or loopback IP addresses are not allowed. Use a public website you own or are authorized to test.');
  u.hash = '';
  return u;
}
function add(findings, severity, title, evidence, fix) { findings.push({ severity, title, evidence, fix, category: 'configuration' }); }
export default async function (req, res) {
  const { url, authorized } = req.body || {};
  if (authorized !== true) return res.status(400).json({ error: 'Confirm that you own this website or have explicit permission to test it.' });
  let target;
  try { target = validateTarget(url); } catch (e) { return res.status(400).json({ error: e.message }); }
  const started = new Date().toISOString();
  const findings = [];
  let status = 'completed';
  let summary = '';
  let responseStatus = null;
  let headers = {};
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    let r;
    let scanUrl = new URL(target.href);
    let redirectsFollowed = 0;
    try {
      for (let hop = 0; hop <= 5; hop++) {
        r = await fetch(scanUrl.href, { method: 'GET', redirect: 'manual', signal: controller.signal, headers: { 'User-Agent': 'AuthorizedSecurityReview/1.0 (passive configuration checks)' } });
        if (r.status < 300 || r.status >= 400) break;
        const location = r.headers.get('location');
        if (!location) break;
        if (hop === 5) { try { await r.body?.cancel(); } catch {} throw new Error('The website exceeded the 5-redirect safety limit.'); }
        const nextUrl = new URL(location, scanUrl.href);
        try { validateTarget(nextUrl.href); } catch { try { await r.body?.cancel(); } catch {} throw new Error('A redirect pointed to a non-public or unsupported destination, so the scanner stopped safely.'); }
        if (nextUrl.hostname.toLowerCase() !== target.hostname.toLowerCase()) { try { await r.body?.cancel(); } catch {} throw new Error('A redirect changed to a different hostname, so the scanner stopped safely.'); }
        try { await r.body?.cancel(); } catch {}
        scanUrl = nextUrl;
        redirectsFollowed++;
      }
    } finally { clearTimeout(timer); }
    responseStatus = r.status;
    const names = ['strict-transport-security','content-security-policy','x-content-type-options','x-frame-options','referrer-policy','permissions-policy'];
    for (const n of names) headers[n] = r.headers.get(n) || '';
    if (target.protocol !== 'https:') add(findings, 'high', 'Website is not using HTTPS', 'The submitted URL uses HTTP, so transport encryption is not established for this URL.', 'Enable HTTPS with a valid certificate and redirect HTTP to HTTPS.');
    else if (!headers['strict-transport-security']) add(findings, 'medium', 'HSTS header not observed', 'Strict-Transport-Security was not present on the response.', 'Consider enabling HSTS after verifying HTTPS works across all subdomains.');
    if (!headers['content-security-policy']) add(findings, 'medium', 'Content Security Policy not observed', 'No Content-Security-Policy response header was detected.', 'Design and test a restrictive CSP that fits the site; avoid blindly copying a policy.');
    if (!headers['x-content-type-options']) add(findings, 'low', 'MIME-sniffing protection not observed', 'X-Content-Type-Options was not present.', 'Set X-Content-Type-Options: nosniff where appropriate.');
    if (!headers['x-frame-options'] && !headers['content-security-policy'].toLowerCase().includes('frame-ancestors')) add(findings, 'low', 'Framing protection not observed', 'Neither X-Frame-Options nor CSP frame-ancestors was detected.', 'Set a suitable frame-ancestors CSP directive or X-Frame-Options.');
    if (!headers['referrer-policy']) add(findings, 'low', 'Referrer-Policy not observed', 'No Referrer-Policy response header was detected.', 'Set an appropriate Referrer-Policy, commonly strict-origin-when-cross-origin.');
    if (r.status >= 500) add(findings, 'medium', 'Server returned an error status', 'The root URL returned HTTP ' + r.status + '.', 'Review server logs and application health. A single response does not prove a vulnerability.');
    if (r.status >= 300 && r.status < 400) add(findings, 'info', 'Redirect response observed', 'The root URL returned HTTP ' + r.status + '. Redirects are not followed by this scanner.', 'Review the Location header manually and ensure it points to an expected destination.');
    const server = r.headers.get('server');
    if (server) add(findings, 'info', 'Server header is exposed', 'Server: ' + server.slice(0, 180), 'Consider minimizing unnecessary technology/version disclosure. This alone is not a vulnerability.');
    try { await r.body?.cancel(); } catch {}
    summary = 'Passive response-header review completed. Final HTTP status: ' + responseStatus + '. Followed ' + redirectsFollowed + ' same-host redirect(s), with a maximum of 5 hops. Checked the final response and common browser security headers only; this is not a full penetration test.';
  } catch (e) {
    status = 'partial';
    add(findings, 'info', 'Website could not be fully inspected', e.name === 'AbortError' ? 'The request exceeded the 10-second timeout.' : String(e.message || 'Network request failed').slice(0, 240), 'Confirm the URL is publicly reachable and retry. Network errors do not prove the website is malicious or vulnerable.');
    summary = 'The scan was partial because the site could not be fetched. No conclusion about overall security can be made.';
  }
  const weights = { critical: 25, high: 15, medium: 8, low: 3, info: 0 };
  const score = Math.max(0, 100 - findings.reduce((n, f) => n + (weights[f.severity] || 0), 0));
  const row = await db.query('INSERT INTO scan_reports (user_id, target_url, status, score, findings, summary) VALUES ($1, $2, $3, $4, $5::jsonb, $6) RETURNING id, target_url, created_at, status, score, findings, summary', [req.user.id, target.href, status, score, JSON.stringify(findings), summary]);
  return res.json({ report: row.rows[0], started_at: started, response_status: responseStatus, headers_checked: headers, scope: 'Passive checks only. No exploit payloads, brute force, authentication bypass, crawling, or destructive tests were performed.' });
}