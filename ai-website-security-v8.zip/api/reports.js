import { db } from 'hatchable';
export const access = 'user';
export const methods = ['GET'];
export default async function (req, res) {
  const { rows } = await db.query('SELECT id, target_url, created_at, status, score, findings, summary FROM scan_reports WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50', [req.user.id]);
  return res.json({ reports: rows });
}